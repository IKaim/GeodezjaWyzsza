import pandas as pd
import plotly.express as px
import gpxpy
import gpxpy.gpx
import numpy as np
from scipy.interpolate import interpn
import math as m
from dash import Dash, dcc, html

app = Dash(__name__)

colors = {
    "background": "#FFFFFF",
    "text": "#312A3F",
    "grid": "#BEB3D5"
}

def blh2xyz(f, l, h):
    a = 6378137
    e2 = 0.00669438002290
    f = np.deg2rad(f)
    l = np.deg2rad(l)
    N = a / (m.sqrt(1 - e2*np.sin(f)*np.sin(f)))
    x = (N+h)*np.cos(f)*np.cos(l)
    y = (N+h)*np.cos(f)*np.sin(l)
    z = (N*(1-e2)+h)*np.sin(f)
    return [x, y, z]

gpx_file_name = 'niebieski-szlak-rowerowy-dookola-rakowa-i-jeziora-chancza.gpx'

with open(gpx_file_name, 'r') as gpx_file:
    gpx = gpxpy.parse(gpx_file)

route_info = []

for track in gpx.tracks:
    for segment in track.segments:
        for point in segment.points:
            route_info.append({
                'latitude': point.latitude,
                'longitude': point.longitude,
                'elevation': point.elevation
            })

route_df = pd.DataFrame(route_info)
dist = [np.nan]

for i in range(len(route_df)):
    if i==0:
        continue
    else:
        phi1 = route_df.iloc[i-1]['latitude']
        lam1 = route_df.iloc[i-1]['longitude']
        h1 = route_df.iloc[i-1]['elevation']
        xyz1 = blh2xyz(phi1, lam1, h1)
        
        phi2 = route_df.iloc[i]['latitude']
        lam2 = route_df.iloc[i]['longitude']
        h2 = route_df.iloc[i]['elevation']
        xyz2 = blh2xyz(phi2, lam2, h2)

        d = np.linalg.norm((np.array(xyz2) - np.array(xyz1))) #w metrach
        dist.append(d)

route_df['distance'] = dist
route_df['cumul_dist'] = route_df['distance'].cumsum()

#interpolacja
model = np.genfromtxt('Model_quasi-geoidy-PL-geoid2021-PL-EVRF2007-NH.txt', skip_header=1)

x = model[:,0]
y = model[:,1]
z = model[:,2]

x_grid = x.reshape((len(np.unique(x)), -1))
y_grid = y.reshape((len(np.unique(x)), -1))
z_grid = z.reshape((len(np.unique(x)), -1))

x_range = x_grid[:,0]
y_range = y_grid[0,:]

z_all = []

for i in range(len(route_df)):
    lat = route_df.iloc[i]['latitude']
    lon = route_df.iloc[i]['longitude']
    point = (lat, lon)
    zeta = interpn((x_range, y_range), z_grid, point)
    z_all.append(zeta)

#wyliczenie wysokości normalnej
wys_n = []
for i in range(len(route_df)):
    h_elip = route_df.iloc[i]['elevation']
    h_n = h_elip - z_all[i][0]
    wys_n.append(h_n)

route_df['Elevation n'] = wys_n

#figury
#mapka osm
fig2 = px.line_mapbox(route_df, lat=route_df['latitude'], lon=route_df['longitude'],
                        color_discrete_sequence=["#35127C"], zoom=11)
fig2.update_layout(mapbox_style="open-street-map")
fig2.update_layout(margin={"r":0,"t":0,"l":0,"b":0})

#profil trasy z wysokosciami elipsoidalnymi
fig = px.line(x = route_df['cumul_dist'], y = route_df['elevation'])
fig.update_layout(title = 'Profil trasy z wysokościami elipsoidalnymi',
                  xaxis_title = 'Distance [m]',
                  yaxis_title = 'Elevation [m]')
fig.update_traces(hovertemplate='distance: %{x:.3f} m <br>elevation: %{y:.2f}')
fig.update_traces(line_color='#35127C')
fig.update_layout(
    plot_bgcolor=colors["background"],
    paper_bgcolor=colors["background"],
    font_color=colors["text"]
)
fig.update_xaxes(gridcolor = colors["grid"])
fig.update_yaxes(gridcolor = colors["grid"])

#profil trasy z wysokosciami normalnymi
fig4 = px.line(x = route_df['cumul_dist'], y = route_df['Elevation n'])
fig4.update_layout(title = 'Profil trasy z wysokościami normalnymi',
                  xaxis_title = 'Distance [m]',
                  yaxis_title = 'Elevation [m]')
fig4.update_traces(hovertemplate='distance: %{x:.3f} m <br>elevation: %{y:.2f}')
fig4.update_traces(line_color='#35127C')
fig4.update_layout(
    plot_bgcolor=colors["background"],
    paper_bgcolor=colors["background"],
    font_color=colors["text"]
)
fig4.update_xaxes(gridcolor = colors["grid"])
fig4.update_yaxes(gridcolor = colors["grid"])

#wykres 3d
fig3 = px.line_3d(route_df, x = route_df['latitude'], y = route_df['longitude'], z = route_df['Elevation n'], height = 800)
fig3.update_layout(title = 'Trasa w 3D')
fig3.update_traces(line_color='#35127C', line_width = 5)
fig3.update_layout(
    plot_bgcolor=colors["background"],
    paper_bgcolor=colors["background"],
    font_color=colors["text"]
)

app.layout = html.Div(style={"backgroundColor": colors["background"]}, children=[
    # mapa osm
    html.Div([
        html.Div([
            html.H1(children='Zadanie 5:  Niebieski szlak rowerowy dookoła rakowa i jeziora chańcza',style={
        "color": colors["text"]
    }),
            html.Div(children="Trasa na tle mapy OSM", style={
        "color": colors["text"]
    }),
            dcc.Graph(
                id='graph1',
                figure=fig2),  
        ]),
    ]),
    # profil trasy wys_elip
    html.Div([
        dcc.Graph(
            id='graph2',
            figure=fig),  
    ]),

    # profil trasy wys_n
    html.Div([
        dcc.Graph(
            id='graph4',
            figure=fig4),  
    ]),

    # wykres 3d
    html.Div([
        dcc.Graph(
            id='graph3',
            figure=fig3),  
    ]),
])

if __name__ == '__main__':
    app.run_server(debug=True)


